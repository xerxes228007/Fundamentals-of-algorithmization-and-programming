#include "statistic.h"
#include "ui_statistic.h"

Statistic::Statistic(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Statistic)
{
    ui->setupUi(this);

    QWidget *desktop = new QWidget();
    int screenW = desktop->width();
    int screenH = desktop->height();
    int windowW = this->size().width();
    int windowH = this->size().height();
    this->move((screenW / 2) - (windowW / 2), (screenH / 2) - (windowH / 2));

    //enterStatisticFromFile();
}

Statistic::~Statistic()
{
    delete ui;
}

void Statistic::addStat(int score, int moves, QString time)
{
    statisticFile.setFileName(pathToFile);
    statisticFile.open(QIODevice::ReadWrite);

    QTextStream myFileStream(&statisticFile);

    QString tempStr;

    do {
        tempStr = myFileStream.readLine();
        stats.append(tempStr + '\n');
    } while (!myFileStream.atEnd());

    QString tempString = ("Time: " + time + " Score: " + QString::number(score)
                          + " Moves: " + QString::number(moves) + '\n');

    stats.append(tempString);
    rewriteFile();
    stats.clear();
    statisticFile.close();
}

void Statistic::enterStatisticFromFile()
{
    if (pathToFile.isEmpty()) {
        return;
    }

    statisticFile.setFileName(pathToFile);
    statisticFile.open(QIODevice::ReadWrite);
    QTextStream myFileStream(&statisticFile);

    QString tempString;

    do {
        tempString = myFileStream.readLine();
        stats.append(tempString);
    } while (!myFileStream.atEnd());

    QString tempString1 = "";

    for (int i = 0; i < stats.size(); i++) {
        tempString1 += stats[i] + '\n';
    }
    ui->textEdit->setText(tempString1);

    statisticFile.close();
}

void Statistic::rewriteFile()
{
    statisticFile.setFileName(pathToFile);
    if (!statisticFile.isOpen()) {
        statisticFile.open(QIODevice::ReadWrite);
    }
    QTextStream myFileStream(&statisticFile);

    QString tempString;

    for (int i = 1; i < stats.size(); i++) {
        tempString += stats[i] + '\n';
    }
    myFileStream << tempString;
    statisticFile.close();
}
