#ifndef STATISTIC_H
#define STATISTIC_H

#include <QFile>
#include <QWidget>

namespace Ui {
class Statistic;
}

class Statistic : public QWidget
{
    Q_OBJECT

public:
    explicit Statistic(QWidget *parent = nullptr);
    ~Statistic();
    void addStat(int score, int moves, QString time);
    void enterStatisticFromFile();
    QString pathToFile = "/home/alexandr/Solitaire/solitaire-main/Statistic.txt";
    QFile statisticFile;

private:
    Ui::Statistic *ui;
    QVector<QString> stats;
    void rewriteFile();
};

#endif // STATISTIC_H
